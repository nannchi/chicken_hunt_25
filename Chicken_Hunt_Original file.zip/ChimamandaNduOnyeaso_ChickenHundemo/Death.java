
public class Death extends Exception
{
    public Death(String type)
    {
        super(type);
    }
}
